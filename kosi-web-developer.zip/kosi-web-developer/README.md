# Kosi | Web Developer

A Pen created on CodePen.

Original URL: [https://codepen.io/editor/Andre-2468/pen/01a0fe2e-3a59-7bc7-ae06-3d6d608f9d6a](https://codepen.io/editor/Andre-2468/pen/01a0fe2e-3a59-7bc7-ae06-3d6d608f9d6a).

My personal portfolio website built with HTML, CSS and JavaScript.